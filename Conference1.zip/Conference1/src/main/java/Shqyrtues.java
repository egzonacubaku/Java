import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


@ManagedBean
@RequestScoped 
public class Shqyrtues {
	
	ArrayList shqyrtuesList, shqyrtuesArtikullList;
	
	private String emri, mbiemri, message, role,temat, institucioni,email,rekomandimi;

	int merita_teknike,kuptueshmeria, origjinaliteti;
	private int shqyrtues_id, nrtel;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	
	public String getEmri() {
		return emri;
	}
	
	public void setEmri(String emri) {
		this.emri = emri;
	}
	
	public String getMbiemri() {
		return mbiemri;
	}
	
	public void setMbiemri(String mbiemri) {
		this.mbiemri = mbiemri;
	}
	
	public int getShqyrtues_id() {
		return shqyrtues_id;
	}
	public void setTemat(String temat) {
		this.temat = temat;
	}
	
	public String getTemat() {
		return temat;
	}
	public void setNrTel(int nrtel) {
		this.nrtel = nrtel;
	}
	
	public int getNrTel() {
		return nrtel;
	}
	public void setInsitucioni(String institucioni) {
		this.institucioni = institucioni;
	}
	
	public String getInstitucioni() {
		return institucioni;
	}
	
	
	public void setShqyrtues_id(int shqyrtues_id) {
		this.shqyrtues_id = shqyrtues_id;
	}
	public void setEmail(String email)
	{
		this.email=email;
	}
	public String getEmail()
	{
		return email;
	}

	public int getMerita_teknike() {
		return merita_teknike;
	}
	public void setMerita_teknike(int merita_teknike) {
		this.merita_teknike = merita_teknike;
	}
	public String getRekomandimi() {
		return rekomandimi;
	}
	public void setRekomandimi(String rekomandimi) {
		this.rekomandimi = rekomandimi;
	}
	public int getKuptueshmeria() {
		return merita_teknike;
	}
	public void setKuptueshmeria(int kuptueshmeria) {
		this.kuptueshmeria = kuptueshmeria;
	}
	public int getOrigjinaliteti() {
		return origjinaliteti;
	}
	public void setOrigjinaliteti(int origjinaliteti) {
		this.origjinaliteti = origjinaliteti;
	}
	
	public ArrayList shqyrtuesList(){
		shqyrtuesList =ShqyrtuesDb.shqyrtuesList();
		
		return shqyrtuesList;
	}
	//list me user te panelit user
	
	public String list() {
		return "/user/reviewers?faces-redirect=true";
	}
	

	
	public String artikull(int shqyrtues_id) {
		String name =ShqyrtuesDb.shqyrtuesName(shqyrtues_id);
		sessionMap.put("shqyrtues_id", shqyrtues_id);
		sessionMap.put("emer", name);
		sessionMap.put("institucioni", institucioni);
		sessionMap.put("email", email);
		sessionMap.put("nrtel", nrtel);
		
		return "/user/article_reviewers?faces-redirect=true";
	}

	public String adminList() {
    	return "/admin/reviewers_index?faces-redirect=true";
    }
	
	public ArrayList shqyrtuesArtikullList(int id){
		shqyrtuesArtikullList = ShqyrtuesDb.shqyrtuesArtikullList(id);
		return shqyrtuesArtikullList;
		}
    
    // Used to delete shqyrtues record
    public static void delete(int id){
        Shqyrtues.delete(id);
    }
    
    //krijimi i nje shqyrtuesi te ri shtimi i nje recordi
    public String saveShqyrtues() {
    	ShqyrtuesDb.save(this);
    	message = "Success! New director created!";
    	return "reviewers_create";
    }
    
    // editimi i te dhenave te shqyrtuesit
    public String edit(int shqyrtues_id) {
    	Shqyrtues d = ShqyrtuesDb.edit(shqyrtues_id);
    	this.shqyrtues_id = shqyrtues_id;
    	this.emri = d.getEmri();
    	this.mbiemri = d.getMbiemri();
    	this.email = d.getEmail();
    	this.temat = d.getTemat();
    	this.institucioni = d.getInstitucioni();
    	this.nrtel = d.getNrTel();

    	return "reviewer_edit";
    }
    
    
    
   
//editimi i te dhenatve te shqyrtuesit
	public String editShqyrtues(int id) {
    	boolean done = ShqyrtuesDb.editShqyrtues(this, id);
        if ( done ) {
        	 message = "Success! Reviewer updated!";
             return "reviewers_index";
        }else {
             message = "Sorry! Could not update reviewers.";
             return "reviewer_edit";
        }
    }

    public String saveAssignShqyrtues(int art_id) {
    	ShqyrtuesDb.saveShqyrtues(this.shqyrtues_id, this.role, art_id);
    	message = "Success! New assign director created!";
    	return "movie_assign_director";
    	//tek user paneli
    }

	
}