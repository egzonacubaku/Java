package dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


@ManagedBean
@RequestScoped 
public class Actor {
	
	ArrayList actorsList, actorMoviesList;
	
	private String emri, datelindja, message, citimi; 
	private int aktor_id;
	
	public String getCitimi() {
		return citimi;
	}
	public void setCitimi(String citimi) {
		this.citimi = citimi;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	
	public String getEmri() {
		return emri;
	}
	public void setEmri(String emri) {
		this.emri = emri;
	}
	public String getDatelindja() {
		return datelindja;
	}
	public void setDatelindja(String datelindja) {
		this.datelindja = datelindja;
	}
	public int getAktor_id() {
		return aktor_id;
	}
	public void setAktor_id(int aktor_id) {
		this.aktor_id = aktor_id;
	}
	
	public ArrayList actorsList(){
		actorsList = ActorDAO.actorsList();
		
		return actorsList;
	}
	
	public String list() {
		return "/user_panel/actor?faces-redirect=true";
	}
	
	public ArrayList actorMoviesList(int id){
		actorMoviesList = ActorDAO.actorMoviesList(id);
		return actorMoviesList;
	}
	
	public String movies(int aktor_id) {
		String name = ActorDAO.actorName(aktor_id);
		sessionMap.put("aktor_id", aktor_id);
		sessionMap.put("name", name);

		return "/user_panel/actor_movies?faces-redirect=true";
	}

	public String adminList() {
    	return "/admin_panel/actor_index?faces-redirect=true";
    }
    
    // Used to delete actor record
    public void delete(int id){
        ActorDAO.delete(id);
    }
    
    // Used to create new actor record
    public String saveActor() {
    	ActorDAO.save(this);
    	message = "Success! New actor created!";
    	return "actor_create";
    }
    
    // Used to edit actor record
    public String edit(int actor_id) {
    	Actor a = ActorDAO.edit(actor_id);
    	this.aktor_id = actor_id;
    	this.emri = a.getEmri();
    	this.datelindja = a.getDatelindja();
    	return "actor_edit";
    }
    
    public String editActor(int id) {
    	boolean done = ActorDAO.editActor(this, id);
        if ( done ) {
        	 message = "Success! Actor updated!";
             return "actor_index";
        }else {
             message = "Sorry! Could not update actor. Please try again!";
             return "actor_edit";
        }
    }
    
    public String saveAssignActor(int movie_id) {
    	ActorDAO.saveAssignActor(this.aktor_id, this.citimi, movie_id);
    	message = "Success! New assign actor created!";
    	return "movie_assign_actors";
    }

}