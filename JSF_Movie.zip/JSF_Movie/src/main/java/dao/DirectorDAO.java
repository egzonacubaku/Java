package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DirectorDAO {
	 
	 public static ArrayList directorsList() {
	        try (Connection con = Database.getConnection()) {
	            Statement stmt=con.createStatement();  
	            ResultSet rs=stmt.executeQuery("select * from regjizor"); 
	            ArrayList directors = new ArrayList();
	            while(rs.next()) {
	                Director d = new Director();
	                d.setDirector_id(rs.getInt("regjizor_id"));
	                d.setEmri(rs.getString("emri"));
	                d.setDatelindja(rs.getString("datelindja"));
	                directors.add(d);
	            }
	            System.out.println("Actors added to list!");
	            return directors;
	        } catch (Exception ex) {
	            System.out.println("DirectorDAO-> directorsList() : " + ex.getMessage());
	            return null;
	        }
	    }
	 
	 public static ArrayList directorMoviesList(int regjizor_id) {
		 try (Connection con = Database.getConnection()) {
	            PreparedStatement stmt=con.prepareStatement("SELECT * FROM film_regjizor, film WHERE film_regjizor.fid= film.film_id AND film_regjizor.rid=?");  
	            stmt.setInt(1, regjizor_id);
	            ResultSet rs=stmt.executeQuery(); 
	            ArrayList movies = new ArrayList();
	            while(rs.next()) {
	                Movie m = new Movie();
	                m.setFilm_id(rs.getInt("film_id"));
	                m.setGjatesia(rs.getInt("gjatesia"));
	                m.setKompania(rs.getString("kompania"));
	                m.setSkenari(rs.getString("skenari"));
	                m.setTitulli(rs.getString("titulli"));
	                m.setViti(rs.getInt("viti"));
	                m.setRoli(rs.getString("roli"));
	                movies.add(m);
	            }
	            System.out.println("Director Movies added to list!");
	            return movies;
	        } catch (Exception ex) {
	            System.out.println("DirectorDAO-> directorMoviesList() : " + ex.getMessage());
	            return null;
	        }
	 }
	 
	 public static String directorName(int director_id) {
		 try (Connection con = Database.getConnection()) {
	            PreparedStatement stmt=con.prepareStatement("select * from regjizor where regjizor_id=?");  
	            stmt.setInt(1, director_id);
	            ResultSet rs=stmt.executeQuery();
	            rs.next();
	            return rs.getString("emri");
	        } catch (Exception ex) {
	            System.out.println("DirectorDAO-> directorName() : " + ex.getMessage());
	            return null;
	        }
	 }
	 
	// Used to delete director record
    public static void delete(int id){
        try{
        	Connection conn = Database.getConnection();  
            PreparedStatement stmt = conn.prepareStatement("delete from regjizor where regjizor_id = "+id);  
            stmt.executeUpdate();  
            System.out.println("Director deleted successfully");
        }catch(Exception e){
        	System.out.println("DirectorDAO->delete() : " + e.getMessage());
        }
    }
		
    // Used to save director record
    public static void save(Director d){
        int result = 0;
        try{
        	Connection conn = Database.getConnection();
            PreparedStatement stmt = conn.prepareStatement("insert into regjizor(emri,datelindja) values(?,?)");
            stmt.setString(1, d.getEmri());
            stmt.setDate(2, Date.valueOf(d.getDatelindja()));
            result = stmt.executeUpdate();
            System.out.println("Director saved successfully!");
            conn.close();
        }catch(Exception e){
        	System.out.println("DirectorDAO->save() : " + e.getMessage());
        }
    }
    
    // Used to fetch record to update
    public static Director edit(int id){
        Director d= null;
        try{
        	Connection conn = Database.getConnection();
            Statement stmt=conn.createStatement();  
            ResultSet rs=stmt.executeQuery("select * from regjizor where regjizor_id = "+(id));
            rs.next();
            d = new Director();
            d.setDirector_id(rs.getInt("regjizor_id"));
            d.setEmri(rs.getString("emri"));
            d.setDatelindja(rs.getString("datelindja"));
            System.out.println("Director data updated!");
            conn.close();
            return d;
        }catch(Exception e){
        	System.out.println("DirectorDAO->edit() : " + e.getMessage());
        	return null;
        }       
    }

    public static boolean editDirector(Director d, int id) {
        try (Connection con = Database.getConnection()) {
            PreparedStatement ps = con.prepareStatement("update regjizor set emri=?, datelindja=? where regjizor_id=?");
            ps.setString(1, d.getEmri());
            ps.setDate(2, Date.valueOf(d.getDatelindja()));
            ps.setInt(3, id);
            System.out.println("Director updated!");
            int count = ps.executeUpdate();
            return count == 1;
        } catch (Exception ex) {
            System.out.println("DirectorDAO->editDirector() : " + ex.getMessage());
            return false;
        }
    }
    
    public static void saveAssignDirector(int regjizor_id, String role, int film_id){
        try{
        	Connection conn = Database.getConnection();
            PreparedStatement stmt = conn.prepareStatement("insert into film_regjizor(fid, rid, roli) values(?,?,?)");
            stmt.setInt(1, film_id);
            stmt.setInt(2, regjizor_id);
            stmt.setString(3, role);
            int result = stmt.executeUpdate();
            System.out.println("Director-Movie saved successfully!");
            conn.close();
        }catch(Exception e){
        	System.out.println("DirectorDAO->saveAssignDirector() : " + e.getMessage());
        }
    }

}
