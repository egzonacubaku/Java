package dao;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import java.util.SimpleTimeZone;

public class ActorDAO {
	 
	 public static ArrayList actorsList() {
	        try (Connection con = Database.getConnection()) {
	            Statement stmt=con.createStatement();  
	            ResultSet rs=stmt.executeQuery("select * from aktor"); 
	            ArrayList actors = new ArrayList();
	            while(rs.next()) {
	                Actor a = new Actor();
	                a.setAktor_id(rs.getInt("aktor_id"));
	                a.setEmri(rs.getString("emri"));
	                a.setDatelindja(rs.getString("datelindja"));
	                actors.add(a);
	            }
	            System.out.println("Actors added to list!");
	            return actors;
	        } catch (Exception ex) {
	            System.out.println("ActorDAO-> actorsList() : " + ex.getMessage());
	            return null;
	        }
	    }
	 
	 public static ArrayList actorMoviesList(int aktor_id) {
		 try (Connection con = Database.getConnection()) {
	            PreparedStatement stmt=con.prepareStatement("SELECT * FROM film_aktor, film WHERE film_aktor.fid= film.film_id AND film_aktor.aid=?");  
	            stmt.setInt(1, aktor_id);
	            ResultSet rs=stmt.executeQuery(); 
	            ArrayList movies = new ArrayList();
	            while(rs.next()) {
	                Movie m = new Movie();
	                m.setFilm_id(rs.getInt("film_id"));
	                m.setGjatesia(rs.getInt("gjatesia"));
	                m.setKompania(rs.getString("kompania"));
	                m.setSkenari(rs.getString("skenari"));
	                m.setTitulli(rs.getString("titulli"));
	                m.setViti(rs.getInt("viti"));
	                m.setCitimi(rs.getString("citimi"));
	                movies.add(m);
	            }
	            System.out.println("Actor Movies added to list!");
	            return movies;
	        } catch (Exception ex) {
	            System.out.println("ActorDAO-> actorMoviesList() : " + ex.getMessage());
	            return null;
	        }
	 }
	 
	 public static String actorName(int aktor_id) {
		 try (Connection con = Database.getConnection()) {
	            PreparedStatement stmt=con.prepareStatement("select * from aktor where aktor_id=?");  
	            stmt.setInt(1, aktor_id);
	            ResultSet rs=stmt.executeQuery();
	            rs.next();
	            return rs.getString("emri");
	        } catch (Exception ex) {
	            System.out.println("ActorDAO-> actorName() : " + ex.getMessage());
	            return null;
	        }
	 }
	 
    // Used to delete actor record
    public static void delete(int id){
        try{
        	Connection conn = Database.getConnection();  
            PreparedStatement stmt = conn.prepareStatement("delete from aktor where aktor_id = "+id);  
            stmt.executeUpdate();  
            System.out.println("Actor deleted successfully");
        }catch(Exception e){
        	System.out.println("ActorDAO->delete() : " + e.getMessage());
        }
    }
	
    // Used to save actor record
    public static void save(Actor a){
        int result = 0;
        try{
        	Connection conn = Database.getConnection();
            PreparedStatement stmt = conn.prepareStatement("insert into aktor(emri,datelindja) values(?,?)");
            stmt.setString(1, a.getEmri());
            stmt.setDate(2, Date.valueOf(a.getDatelindja()));
            result = stmt.executeUpdate();
            System.out.println("Actor saved successfully!");
            conn.close();
        }catch(Exception e){
        	System.out.println("ActorDAO->save() : " + e.getMessage());
        }
    }
    
    // Used to fetch record to update
    public static Actor edit(int id){
        Actor a= null;
        try{
        	Connection conn = Database.getConnection();
            Statement stmt=conn.createStatement();  
            ResultSet rs=stmt.executeQuery("select * from aktor where aktor_id = "+(id));
            rs.next();
            a = new Actor();
            a.setAktor_id(rs.getInt("aktor_id"));
            a.setEmri(rs.getString("emri"));
            a.setDatelindja(rs.getString("datelindja"));
            System.out.println("Actor data updated!");
            conn.close();
            return a;
        }catch(Exception e){
        	System.out.println("ActorDAO->edit() : " + e.getMessage());
        	return null;
        }       
    }

    public static boolean editActor(Actor a, int id) {
        try (Connection con = Database.getConnection()) {
            PreparedStatement ps = con.prepareStatement("update aktor set emri=?, datelindja=? where aktor_id=?");
            ps.setString(1, a.getEmri());
            ps.setDate(2, Date.valueOf(a.getDatelindja()));
            ps.setInt(3, id);
            System.out.println("Actor updated!");
            int count = ps.executeUpdate();
            return count == 1;
        } catch (Exception ex) {
            System.out.println("ActorDAO->editActor() : " + ex.getMessage());
            return false;
        }
    }
    
    public static void saveAssignActor(int aktor_id, String citimi, int film_id){
        try{
        	Connection conn = Database.getConnection();
            PreparedStatement stmt = conn.prepareStatement("insert into film_aktor(fid, aid, citimi) values(?,?,?)");
            stmt.setInt(1, film_id);
            stmt.setInt(2, aktor_id);
            stmt.setString(3, citimi);
            int result = stmt.executeUpdate();
            System.out.println("Actor-Movie saved successfully!");
            conn.close();
        }catch(Exception e){
        	System.out.println("ActorDAO->saveAssignActor() : " + e.getMessage());
        }
    }
	    
}
