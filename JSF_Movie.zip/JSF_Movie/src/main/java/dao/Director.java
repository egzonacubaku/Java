package dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


@ManagedBean
@RequestScoped 
public class Director {
	
	ArrayList directorsList, directorMoviesList;
	
	private String emri, datelindja, message, role;
	private int director_id;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	private Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	
	public String getEmri() {
		return emri;
	}
	
	public void setEmri(String emri) {
		this.emri = emri;
	}
	
	public String getDatelindja() {
		return datelindja;
	}
	
	public void setDatelindja(String datelindja) {
		this.datelindja = datelindja;
	}
	
	public int getDirector_id() {
		return director_id;
	}
	
	public void setDirector_id(int director_id) {
		this.director_id = director_id;
	}
	
	public ArrayList directorsList(){
		directorsList = DirectorDAO.directorsList();
		
		return directorsList;
	}
	
	public String list() {
		return "/user_panel/director?faces-redirect=true";
	}
	
	public ArrayList directorMoviesList(int id){
		directorMoviesList = DirectorDAO.directorMoviesList(id);
		return directorMoviesList;
	}
	
	public String movies(int director_id) {
		String name = DirectorDAO.directorName(director_id);
		sessionMap.put("director_id", director_id);
		sessionMap.put("director_name", name);

		return "/user_panel/director_movies?faces-redirect=true";
	}

	public String adminList() {
    	return "/admin_panel/director_index?faces-redirect=true";
    }
    
    // Used to delete director record
    public void delete(int id){
        DirectorDAO.delete(id);
    }
    
    // Used to create new director record
    public String saveDirector() {
    	DirectorDAO.save(this);
    	message = "Success! New director created!";
    	return "director_create";
    }
    
    // Used to edit director record
    public String edit(int director_id) {
    	Director d = DirectorDAO.edit(director_id);
    	this.director_id = director_id;
    	this.emri = d.getEmri();
    	this.datelindja = d.getDatelindja();
    	return "director_edit";
    }
    
    public String editDirector(int id) {
    	boolean done = DirectorDAO.editDirector(this, id);
        if ( done ) {
        	 message = "Success! Director updated!";
             return "director_index";
        }else {
             message = "Sorry! Could not update director. Please try again!";
             return "director_edit";
        }
    }

    public String saveAssignDirector(int movie_id) {
    	DirectorDAO.saveAssignDirector(this.director_id, this.role, movie_id);
    	message = "Success! New assign director created!";
    	return "movie_assign_director";
    }
}